STEEL FRONT ONLINE — АВТОУСТАНОВКА ДЛЯ DAGOR ENGINE

1) Распакуй весь ZIP в обычную папку, например D:\DagorDev\Installer.
2) Запусти Install-And-Run-SteelFront.bat двойным щелчком.
3) Не закрывай окно PowerShell. При ошибке окно останется открытым.
4) Полный лог: %LOCALAPPDATA%\SteelFront\install-and-run.log

Установщик использует официальные публичные материалы Gaijin Dagor Engine:
- исходники Dagor Engine (GitHub main);
- tools-base, samples-base, outerSpace-devsrc (head-2026.11.07);
- tools-prebuilt-windows-x86_64.7z;
- outerSpace-prebuilt-fullsrc.tar.gz.

Требования:
- Windows 10/11 x64;
- диск D: (в этом пакете путь задан как D:\DagorDev);
- много свободного места. README Dagor указывает 200 GB для полного комплекта;
- 7-Zip (BAT попытается поставить через winget);
- Python 3 (BAT попытается поставить через winget);
- интернет и возможность загружать крупные архивы с CDN Gaijin/GitHub.

ВАЖНО О СОСТОЯНИИ ИГРЫ:
Это не готовая самостоятельная игра и не War Thunder. Это проект-прототип на публичном Dagor Engine / Outer Space sample: тестовая сцена, локальный master server и клиент на базе существующего sample. Сейчас используется штатная тестовая физика/модель Outer Space (motorbike). Atlas_Crawler.obj хранится как исходный 3D-ресурс, но ещё не интегрирован как управляемая машина. Установщик не гарантирует успешную сборку на каждом ПК; при сбое приложи install-and-run.log.

Не публикуй локальный master server в открытый интернет. В этом пакете он предназначен только для localhost.
