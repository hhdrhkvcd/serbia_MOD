@echo off
setlocal
chcp 65001 >nul
title STEEL FRONT ONLINE - DAGOR ENGINE
color 0B

echo =====================================================
echo        STEEL FRONT ONLINE - DAGOR ENGINE
echo =====================================================
echo.
echo This installs the public Dagor SDK resources, then prepares
echo and starts the Steel Front non-combat driving prototype.
echo.
echo IMPORTANT: The full Dagor SDK needs substantial disk space.
echo The installer keeps the PowerShell window open if anything fails.
echo.

where powershell.exe >nul 2>nul
if errorlevel 1 (
  echo ERROR: Windows PowerShell not found.
  pause
  exit /b 1
)

if not exist "%~dp0Install-And-Run-SteelFront.ps1" (
  echo ERROR: Install-And-Run-SteelFront.ps1 is missing.
  echo Extract the COMPLETE ZIP folder first. Do not run BAT from inside the ZIP preview.
  pause
  exit /b 1
)

if not exist "%~dp0SteelFront_Dagor_Online\Install-SteelFront-Dagor.ps1" (
  echo ERROR: SteelFront_Dagor_Online folder is missing.
  echo Extract the COMPLETE ZIP folder first.
  pause
  exit /b 1
)

echo Starting installer. Keep the PowerShell window open.
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -NoExit -File "%~dp0Install-And-Run-SteelFront.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
echo Installer process ended with code %RESULT%.
echo Log: %LOCALAPPDATA%\SteelFront\install-and-run.log
echo.
pause
exit /b %RESULT%
