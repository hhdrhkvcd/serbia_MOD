[CmdletBinding()]
param(
    [string]$Root = 'D:\DagorDev',
    [switch]$SkipBuild
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$EngineRoot = Join-Path $Root 'DagorEngine'
$ProjectRoot = Join-Path $Root 'SteelFront'
$Downloads = Join-Path $Root 'Downloads'
$LogDir = Join-Path $env:LOCALAPPDATA 'SteelFront'
$LogPath = Join-Path $LogDir 'install-and-run.log'
$TranscriptStarted = $false

function Write-Step([string]$Message) {
    Write-Host "`n=== $Message ===" -ForegroundColor Cyan
}

function Refresh-Path {
    $machinePath = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $userPath = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = @($machinePath, $userPath) -join ';'
}

function Get-7Zip {
    $candidates = @(
        "$env:ProgramFiles\7-Zip\7z.exe",
        "${env:ProgramFiles(x86)}\7-Zip\7z.exe",
        "$env:LOCALAPPDATA\Programs\7-Zip\7z.exe"
    )
    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) { return $candidate }
    }
    $cmd = Get-Command 7z.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

function Ensure-Package([string]$Id) {
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if (-not $winget) { throw "Не найден winget. Установи 'App Installer' из Microsoft Store, затем повтори запуск." }
    Write-Host "Устанавливаю $Id через winget..." -ForegroundColor Yellow
    & $winget.Source install --id $Id --exact --silent --accept-source-agreements --accept-package-agreements
    if ($LASTEXITCODE -ne 0) { throw "winget не смог установить $Id (код $LASTEXITCODE)." }
    Refresh-Path
}

function Get-PythonLauncher {
    Refresh-Path
    $cmd = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $paths = @(
        "$env:LOCALAPPDATA\Programs\Python\Launcher\py.exe",
        "$env:WINDIR\py.exe"
    )
    foreach ($p in $paths) { if (Test-Path -LiteralPath $p -PathType Leaf) { return $p } }
    return $null
}

function Download-Checked([string]$Url, [string]$Destination, [long]$MinimumBytes = 1000000) {
    if ((Test-Path -LiteralPath $Destination -PathType Leaf) -and (Get-Item -LiteralPath $Destination).Length -ge $MinimumBytes) {
        Write-Host "Уже загружен: $Destination" -ForegroundColor DarkYellow
        return
    }
    if (Test-Path -LiteralPath $Destination) { Remove-Item -LiteralPath $Destination -Force }
    $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
    if (-not $curl) { throw 'Не найден curl.exe. Нужна Windows 10/11 с системным curl.' }
    Write-Host "Загружаю $([IO.Path]::GetFileName($Destination))" -ForegroundColor Yellow
    & $curl.Source -fL --retry 5 --retry-delay 3 --connect-timeout 30 --progress-bar $Url -o $Destination
    if ($LASTEXITCODE -ne 0) { throw "Загрузка не удалась (curl $LASTEXITCODE): $Url" }
    if (-not (Test-Path -LiteralPath $Destination -PathType Leaf)) { throw "Файл не создан: $Destination" }
    $length = (Get-Item -LiteralPath $Destination).Length
    if ($length -lt $MinimumBytes) { throw "Скачанный файл подозрительно мал ($length байт): $Destination" }
}

function Expand-7z([string]$SevenZip, [string]$Archive, [string]$Destination) {
    New-Item -ItemType Directory -Force -Path $Destination | Out-Null
    Write-Host "Распаковываю $([IO.Path]::GetFileName($Archive))..." -ForegroundColor Yellow
    & $SevenZip x $Archive "-o$Destination" -aos -y
    if ($LASTEXITCODE -gt 1) { throw "7-Zip: ошибка распаковки $Archive (код $LASTEXITCODE)." }
}

function Invoke-ScriptChecked([string]$ScriptPath, [string[]]$Arguments = @()) {
    if (-not (Test-Path -LiteralPath $ScriptPath -PathType Leaf)) { throw "Не найден скрипт: $ScriptPath" }
    $argLine = @('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $ScriptPath + '"'))
    foreach ($arg in $Arguments) { $argLine += $arg }
    $p = Start-Process -FilePath 'powershell.exe' -ArgumentList $argLine -Wait -PassThru -NoNewWindow
    if ($p.ExitCode -ne 0) { throw "Скрипт завершился с кодом $($p.ExitCode): $ScriptPath" }
}

try {
    New-Item -ItemType Directory -Force -Path $Root,$Downloads,$LogDir | Out-Null
    Start-Transcript -Path $LogPath -Append | Out-Null
    $TranscriptStarted = $true

    Write-Host 'STEEL FRONT ONLINE — УСТАНОВКА ДЛЯ DAGOR ENGINE' -ForegroundColor Cyan
    Write-Host "Лог: $LogPath" -ForegroundColor DarkGray

    if (-not [Environment]::Is64BitOperatingSystem) { throw 'Требуется 64-разрядная Windows 10/11.' }
    if (-not (Test-Path -LiteralPath ([IO.Path]::GetPathRoot($Root)))) { throw "Не найден диск для папки $Root" }
    $driveLetter = [IO.Path]::GetPathRoot($Root).Substring(0,1)
    $drive = Get-PSDrive -Name $driveLetter -ErrorAction Stop
    $freeGB = [math]::Round($drive.Free / 1GB, 1)
    Write-Host "Свободно на диске $driveLetter`: $freeGB GB"
    if ($drive.Free -lt 200GB) {
        throw "Официальный README Dagor указывает 200 GB для полного комплекта SDK. Сейчас свободно $freeGB GB; освободи место и повтори."
    }

    Write-Step 'Проверка 7-Zip и Python'
    $sevenZip = Get-7Zip
    if (-not $sevenZip) {
        Ensure-Package '7zip.7zip'
        $sevenZip = Get-7Zip
    }
    if (-not $sevenZip) { throw '7-Zip не найден после установки.' }

    $python = Get-PythonLauncher
    if (-not $python) {
        Ensure-Package 'Python.Python.3.13'
        $python = Get-PythonLauncher
    }
    if (-not $python) { throw 'Не найден Python Launcher py.exe.' }
    & $python -3 --version
    if ($LASTEXITCODE -ne 0) { throw 'Python Launcher найден, но Python 3 не запускается.' }

    Write-Step 'Исходники официального Dagor Engine'
    if (-not ((Test-Path -LiteralPath (Join-Path $EngineRoot 'build_all.py')) -and (Test-Path -LiteralPath (Join-Path $EngineRoot 'outerSpace\prog\build.py')))) {
        $sourceZip = Join-Path $Downloads 'DagorEngine-main.zip'
        Download-Checked 'https://codeload.github.com/GaijinEntertainment/DagorEngine/zip/refs/heads/main' $sourceZip 20000000
        $sourceStage = Join-Path $Downloads 'DagorEngine-main-extract'
        if (Test-Path -LiteralPath $sourceStage) { Remove-Item -LiteralPath $sourceStage -Recurse -Force }
        Expand-Archive -LiteralPath $sourceZip -DestinationPath $sourceStage -Force
        $sourceRoot = Get-ChildItem -LiteralPath $sourceStage -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'build_all.py') } | Select-Object -First 1
        if (-not $sourceRoot) { throw 'В архиве GitHub не найдена корневая папка Dagor Engine (build_all.py).' }
        if (Test-Path -LiteralPath $EngineRoot) {
            $backup = "$EngineRoot.incomplete_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
            Move-Item -LiteralPath $EngineRoot -Destination $backup
            Write-Host "Старая неполная папка перемещена в $backup" -ForegroundColor Yellow
        }
        Move-Item -LiteralPath $sourceRoot.FullName -Destination $EngineRoot
    } else {
        Write-Host 'Исходники Dagor уже присутствуют.' -ForegroundColor DarkYellow
    }

    Write-Step 'Официальные ресурсы и готовые Windows-бинарники Gaijin'
    $head = 'https://dagorenginedata.cdn.gaijin.net/head-2026.11.07'
    $rel = 'https://dagorenginedata.cdn.gaijin.net/rel-0ebc89d5d795f3f96324843abf72c5ca7b8555cf'
    $archives = @(
        @{ Name='tools-base.7z'; Url="$head/tools-base.7z"; Check=(Join-Path $EngineRoot 'tools') },
        @{ Name='samples-base.7z'; Url="$head/samples-base.7z"; Check=(Join-Path $EngineRoot 'samples') },
        @{ Name='outerSpace-devsrc.7z'; Url="$head/outerSpace-devsrc.7z"; Check=(Join-Path $EngineRoot 'outerSpace\develop\assets') },
        @{ Name='tools-prebuilt-windows-x86_64.7z'; Url="$rel/tools-prebuilt-windows-x86_64.7z"; Check=(Join-Path $EngineRoot 'tools\dagor3_cdk\bin') }
    )
    foreach ($a in $archives) {
        $dest = Join-Path $Downloads $a.Name
        Download-Checked $a.Url $dest 1000000
        Expand-7z $sevenZip $dest $EngineRoot
    }

    $runtimeArchive = Join-Path $Downloads 'outerSpace-prebuilt-fullsrc.tar.gz'
    Download-Checked "$rel/outerSpace-prebuilt-fullsrc.tar.gz" $runtimeArchive 100000000
    $runtimeStage = Join-Path $Downloads 'OuterSpace-prebuilt-unpack'
    if (Test-Path -LiteralPath $runtimeStage) { Remove-Item -LiteralPath $runtimeStage -Recurse -Force }
    Expand-7z $sevenZip $runtimeArchive $runtimeStage
    $tarFile = Get-ChildItem -LiteralPath $runtimeStage -Filter '*.tar' -File -Recurse | Select-Object -First 1
    if (-not $tarFile) { throw 'Архив Outer Space не содержит TAR после распаковки GZ. Проверь скачивание.' }
    Expand-7z $sevenZip $tarFile.FullName $EngineRoot

    $clientExe = Join-Path $EngineRoot 'outerSpace\game\windows-x86_64\outer_space-dev.exe'
    $serverExe = Join-Path $EngineRoot 'outerSpace\game\windows-x86_64\outer_space-ded-dev.exe'
    if (-not (Test-Path -LiteralPath $clientExe)) { throw "После установки не найден игровой клиент: $clientExe" }
    if (-not (Test-Path -LiteralPath $serverExe)) { throw "После установки не найден dedicated server: $serverExe" }

    Write-Step 'Загрузка файлов проекта Steel Front'
    $pageUrl = 'https://raw.githubusercontent.com/hhdrhkvcd/serbia_MOD/steel-front-download/SteelFront_Download/index.html'
    $pageFile = Join-Path $Downloads 'SteelFront_DownloadPage.html'
    $projectZip = Join-Path $Downloads 'SteelFront_Dagor_Online_v0.1.zip'
    Download-Checked $pageUrl $pageFile 10000
    $html = [IO.File]::ReadAllText($pageFile)
    if ($html -notmatch 'const\s+archiveBase64\s*=\s*"([A-Za-z0-9+/=]+)"') {
        throw 'В опубликованной странице GitHub не найден встроенный ZIP проекта Steel Front.'
    }
    $zipBytes = [Convert]::FromBase64String($Matches[1])
    [IO.File]::WriteAllBytes($projectZip, $zipBytes)
    if ($zipBytes.Length -lt 100000) { throw 'Скачанный ZIP проекта Steel Front слишком мал или повреждён.' }
    $ProjectPack = Join-Path $Root 'SteelFront_Pack'
    if (Test-Path -LiteralPath $ProjectPack) { Remove-Item -LiteralPath $ProjectPack -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $ProjectPack | Out-Null
    Expand-Archive -LiteralPath $projectZip -DestinationPath $ProjectPack -Force
    $packRoot = Join-Path $ProjectPack 'SteelFront_Dagor_Online'
    if (-not (Test-Path -LiteralPath (Join-Path $packRoot 'Install-SteelFront-Dagor.ps1'))) {
        throw "В архиве проекта не найден установщик: $packRoot\Install-SteelFront-Dagor.ps1"
    }
    $installer = Join-Path $packRoot 'Install-SteelFront-Dagor.ps1'
    Invoke-ScriptChecked $installer @('-EngineRoot', $EngineRoot, '-ProjectRoot', $ProjectRoot)

    if (-not $SkipBuild) {
        Write-Step 'Сборка игровых ресурсов Dagor'
        $builder = Join-Path $ProjectRoot 'Build-SteelFront.ps1'
        Invoke-ScriptChecked $builder @('-EngineRoot', $EngineRoot)
    } else {
        Write-Host 'Сборка пропущена параметром SkipBuild.' -ForegroundColor Yellow
    }

    Write-Step 'Запуск локального мультиплеера и клиента'
    $runner = Join-Path $ProjectRoot 'Run-Local-Multiplayer.ps1'
    Invoke-ScriptChecked $runner @('-EngineRoot', $EngineRoot)

    Write-Host "`nГотово. Если окно игры не появилось, смотри лог: $LogPath" -ForegroundColor Green
    Write-Host 'Это Dagor Outer Space sample с тестовой сценой Steel Front; собственная машина Atlas пока не интегрирована в физику игры.' -ForegroundColor Yellow
}
catch {
    Write-Host "`nОШИБКА: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Подробности записаны в: $LogPath" -ForegroundColor Yellow
    Write-Host $_.ScriptStackTrace -ForegroundColor DarkGray
    exit 1
}
finally {
    if ($TranscriptStarted) { Stop-Transcript | Out-Null }
}
