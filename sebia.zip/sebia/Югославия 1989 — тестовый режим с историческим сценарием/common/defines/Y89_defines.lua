-- Настройки временной шкалы сценария «Югославия 1989».
NDefines.NGame.START_DATE = "1989.1.1.12"
NDefines.NGame.END_DATE = "2100.1.1.1"
NDefines.NDiplomacy.TENSION_TIME_SCALE_START_DATE = "1989.1.1.12"
