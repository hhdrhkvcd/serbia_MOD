@echo off
setlocal
cd /d "%~dp0"
if not exist "build\SteelFrontOffline.exe" (
    echo Steel Front EXE was not found.
    echo Run BUILD_EXE.bat first.
    pause
    exit /b 1
)
start "Steel Front Offline" "%~dp0build\SteelFrontOffline.exe"
