@echo off
setlocal
cd /d "%~dp0"
if not exist "build\SteelFrontOffline.exe" (
  echo Game EXE not found. Build the project first with BUILD_EXE.bat.
  pause
  exit /b 1
)
echo Starting Steel Front and writing the startup log to startup_log.txt
"%~dp0build\SteelFrontOffline.exe" --verbose --log-file "%~dp0startup_log.txt"
echo.
echo Log path: %~dp0startup_log.txt
echo Send startup_log.txt if the screen is still blank.
pause
