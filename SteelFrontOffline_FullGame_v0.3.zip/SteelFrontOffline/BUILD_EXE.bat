@echo off
setlocal
cd /d "%~dp0"
echo STEEL FRONT OFFLINE - WINDOWS EXE BUILDER
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_EXE.ps1"
if errorlevel 1 (
    echo.
    echo BUILD FAILED. Read the error message above.
    pause
    exit /b 1
)
echo.
echo BUILD FINISHED.
pause
