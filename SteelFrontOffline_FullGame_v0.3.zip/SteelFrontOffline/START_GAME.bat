@echo off
setlocal
cd /d "%~dp0"
if not exist "build\SteelFrontOffline.exe" (
    echo First launch: building Steel Front Offline.
    echo The first build downloads the official Godot 4.3 editor and export template.
    echo.
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_EXE.ps1"
    if errorlevel 1 (
        echo.
        echo BUILD FAILED. Read the PowerShell error above.
        pause
        exit /b 1
    )
)
if not exist "build\SteelFrontOffline.exe" (
    echo The build finished without producing build\SteelFrontOffline.exe.
    pause
    exit /b 1
)
start "Steel Front Offline" "%~dp0build\SteelFrontOffline.exe"
