$ErrorActionPreference = "Stop"
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

# ASCII-only for Windows PowerShell 5.1 compatibility.
# The build is self-contained: caches and Godot user data stay in this project.
$ProjectRoot = (Get-Item -LiteralPath $MyInvocation.MyCommand.Path).Directory.FullName
$BuildDir = Join-Path $ProjectRoot "build"
$WorkRoot = Join-Path $ProjectRoot ".build_tools"
$BuildTemp = Join-Path $ProjectRoot ".build_temp"
$AppDataRoot = Join-Path $ProjectRoot ".build_appdata"
$EditorZip = Join-Path $WorkRoot "godot_editor.zip"
$TemplatesTpz = Join-Path $WorkRoot "export_templates.tpz"
$EditorDir = Join-Path $WorkRoot "editor"
$TemplatesDir = Join-Path $WorkRoot "templates"
$InstallTemplatesDir = Join-Path $AppDataRoot "Godot\export_templates\4.3.stable"
$OutputExe = Join-Path $BuildDir "SteelFrontOffline.exe"

function Write-Step([string]$Message) {
    Write-Host ""
    Write-Host ("==> " + $Message) -ForegroundColor Cyan
}

function Download-OfficialFile([string[]]$Urls, [string]$Destination) {
    # Reuse a complete previous download instead of downloading it on every retry.
    if ((Test-Path -LiteralPath $Destination) -and (Get-Item -LiteralPath $Destination).Length -gt 1000000) {
        Write-Host ("Using cached download: " + $Destination)
        return
    }

    if (Test-Path -LiteralPath $Destination) {
        Remove-Item -LiteralPath $Destination -Force
    }
    $lastError = "No download URL was attempted."

    foreach ($url in $Urls) {
        try {
            Write-Host ("Downloading: " + $url)
            Invoke-WebRequest -Uri $url -OutFile $Destination -UseBasicParsing
            if ((Test-Path -LiteralPath $Destination) -and (Get-Item -LiteralPath $Destination).Length -gt 1000000) {
                return
            }
            throw "The downloaded file is missing or smaller than 1 MB."
        }
        catch {
            $lastError = $_.Exception.Message
            if (Test-Path -LiteralPath $Destination) {
                Remove-Item -LiteralPath $Destination -Force
            }
            Write-Warning ("Download failed: " + $lastError)
        }
    }

    throw ("Could not download the official Godot file. Last error: " + $lastError)
}

try {
    Write-Host "STEEL FRONT OFFLINE - WINDOWS EXE BUILDER" -ForegroundColor Green
    Write-Host "Internet is needed only when Godot tools are not already cached."
    Write-Host ("Project folder: " + $ProjectRoot)
    Write-Host "Build files and Godot cache stay inside this project folder."

    if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot "project.godot"))) {
        throw "project.godot was not found. Keep this script inside the project folder."
    }
    if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot "export_presets.cfg"))) {
        throw "export_presets.cfg was not found."
    }

    $MainScriptPath = Join-Path $ProjectRoot "scripts\main.gd"
    if (-not (Test-Path -LiteralPath $MainScriptPath)) {
        throw "scripts\main.gd was not found."
    }
    $MainScriptText = Get-Content -LiteralPath $MainScriptPath -Raw
    $RequiredScriptMarkers = @(
        "var player: CharacterBody3D",
        "var behind: Vector3",
        "var desired_camera: Vector3",
        "var distance: float",
        "const NATIONS := [",
        "const VEHICLES := [",
        "FULL GAME 0.3 / hangar, free drive, time trial, records",
        "func _start_free_drive() -> void:",
        "func _store_best_time(vehicle_id: String, seconds: float) -> bool:",
        "func _pause_game() -> void:"
    )
    foreach ($marker in $RequiredScriptMarkers) {
        if (-not $MainScriptText.Contains($marker)) {
            throw ("The game script is outdated. Missing marker: " + $marker + ". Extract the current project archive into a NEW folder and build from there.")
        }
    }

    New-Item -ItemType Directory -Force -Path $WorkRoot, $EditorDir, $TemplatesDir, $BuildDir, $BuildTemp, $AppDataRoot | Out-Null
    $env:TEMP = $BuildTemp
    $env:TMP = $BuildTemp
    $env:APPDATA = $AppDataRoot
    $env:LOCALAPPDATA = $AppDataRoot

    # Remove an old EXE and editor cache so only the current script is exported.
    if (Test-Path -LiteralPath $OutputExe) {
        Remove-Item -LiteralPath $OutputExe -Force
    }
    $GodotCache = Join-Path $ProjectRoot ".godot"
    if (Test-Path -LiteralPath $GodotCache) {
        Remove-Item -LiteralPath $GodotCache -Recurse -Force
    }

    $amp = [string][char]38
    $editorUrl = "https://downloads.godotengine.org/?flavor=stable${amp}platform=windows.64${amp}slug=win64.exe.zip${amp}version=4.3"
    $templatesUrl = "https://downloads.godotengine.org/?flavor=stable${amp}platform=templates${amp}slug=export_templates.tpz${amp}version=4.3"

    $GodotExe = Get-ChildItem -LiteralPath $EditorDir -Filter "*console.exe" -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $GodotExe) {
        Write-Step "Downloading Godot 4.3 for Windows x64"
        Download-OfficialFile -Urls @(
            $editorUrl,
            "https://downloads.tuxfamily.org/godotengine/4.3/Godot_v4.3-stable_win64.exe.zip"
        ) -Destination $EditorZip

        Write-Step "Extracting Godot editor"
        Get-ChildItem -LiteralPath $EditorDir -Force | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        Expand-Archive -LiteralPath $EditorZip -DestinationPath $EditorDir -Force
        $GodotExe = Get-ChildItem -LiteralPath $EditorDir -Filter "*console.exe" -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1
    }
    if (-not $GodotExe) {
        $GodotExe = Get-ChildItem -LiteralPath $EditorDir -Filter "*win64.exe" -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1
    }
    if (-not $GodotExe) {
        throw "Godot executable was not found inside the downloaded archive."
    }

    $ReleaseTemplate = Get-ChildItem -LiteralPath $TemplatesDir -Filter "windows_release_x86_64.exe" -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $ReleaseTemplate) {
        Write-Step "Downloading Godot 4.3 export templates"
        Download-OfficialFile -Urls @(
            $templatesUrl,
            "https://downloads.tuxfamily.org/godotengine/4.3/Godot_v4.3-stable_export_templates.tpz"
        ) -Destination $TemplatesTpz

        Write-Step "Extracting export templates"
        Get-ChildItem -LiteralPath $TemplatesDir -Force | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        $TemplatesZip = Join-Path $WorkRoot "export_templates.zip"
        Copy-Item -LiteralPath $TemplatesTpz -Destination $TemplatesZip -Force
        Expand-Archive -LiteralPath $TemplatesZip -DestinationPath $TemplatesDir -Force
        $ReleaseTemplate = Get-ChildItem -LiteralPath $TemplatesDir -Filter "windows_release_x86_64.exe" -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1
    }
    if (-not $ReleaseTemplate) {
        throw "The Windows x86_64 release template was not found."
    }

    Write-Step "Installing the export template into the project-local Godot data folder"
    New-Item -ItemType Directory -Force -Path $InstallTemplatesDir | Out-Null
    Copy-Item -LiteralPath $ReleaseTemplate.FullName -Destination (Join-Path $InstallTemplatesDir "windows_release_x86_64.exe") -Force
    $VersionFile = Get-ChildItem -LiteralPath $TemplatesDir -Filter "version.txt" -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($VersionFile) {
        Copy-Item -LiteralPath $VersionFile.FullName -Destination (Join-Path $InstallTemplatesDir "version.txt") -Force
    }
    else {
        Set-Content -LiteralPath (Join-Path $InstallTemplatesDir "version.txt") -Value "4.3.stable" -Encoding ASCII
    }

    Write-Step "Importing project and checking GDScript"
    $ImportOutput = & $GodotExe.FullName --headless --path $ProjectRoot --editor --quit 2>&1
    $ImportExitCode = $LASTEXITCODE
    $ImportOutput | ForEach-Object { Write-Host $_ }
    $ImportText = $ImportOutput -join "`n"
    if ($ImportExitCode -ne 0 -or $ImportText -match '(?i)SCRIPT ERROR|Parse Error|ERROR: Failed to load script') {
        throw ("Godot project check failed. Exit code: " + $ImportExitCode + ". Fix the script errors shown above before exporting.")
    }

    # Do NOT run the actual 3D scene with --headless. Godot 4.3's Dummy Renderer
    # can emit a false-positive mesh error when MeshInstance3D nodes are created
    # and freed. This is separate from the normal desktop renderer used by the EXE.
    Write-Step "Skipping headless 3D startup test (Godot 4.3 Dummy Renderer limitation)"
    Write-Host "GDScript import check passed. The exported EXE will use the normal desktop renderer."

    # Godot 4.3 invokes rcedit when Application > Modify Resources is enabled.
    # rcedit is an optional metadata/icon utility and may be unavailable on some PCs.
    # Force it off: the EXE remains fully playable, but keeps the default Godot icon
    # and does not receive custom Windows version-resource metadata.
    $PresetPath = Join-Path $ProjectRoot "export_presets.cfg"
    $PresetText = Get-Content -LiteralPath $PresetPath -Raw
    $PresetText = [regex]::Replace($PresetText, '(?m)^application/modify_resources\s*=\s*true\s*$', 'application/modify_resources=false')
    if ($PresetText -notmatch '(?m)^application/modify_resources\s*=\s*false\s*$') {
        throw "Could not verify application/modify_resources=false in export_presets.cfg."
    }
    Set-Content -LiteralPath $PresetPath -Value $PresetText -Encoding ASCII

    Write-Step "Exporting the Windows EXE (without optional rcedit metadata editing)"
    $ExportOutput = & $GodotExe.FullName --headless --path $ProjectRoot --export-release "Windows Desktop" $OutputExe 2>&1
    $ExportExitCode = $LASTEXITCODE
    $ExportOutput | ForEach-Object { Write-Host $_ }
    $ExportText = $ExportOutput -join "`n"
    if ($ExportText -match '(?i)SCRIPT ERROR|Parse Error|ERROR: Failed to load script') {
        throw ("Godot export reported a script error. Exit code: " + $ExportExitCode + ". Check the errors above.")
    }
    if ($ExportExitCode -ne 0) {
        throw ("Godot export failed with exit code " + $ExportExitCode + ". Check the output above.")
    }
    if (-not (Test-Path -LiteralPath $OutputExe)) {
        throw "Godot did not create build\SteelFrontOffline.exe."
    }
    if ((Get-Item -LiteralPath $OutputExe).Length -lt 1000000) {
        throw "The exported EXE is unexpectedly small. Check the Godot output above."
    }

    Write-Host ""
    Write-Host "BUILD COMPLETE" -ForegroundColor Green
    Write-Host ("EXE: " + $OutputExe) -ForegroundColor Yellow
    Write-Host "The game file has been exported. Run it normally from Windows; do not add --headless."
    Start-Process explorer.exe ("/select,`"" + $OutputExe + "`"")
}
catch {
    Write-Host ""
    Write-Host ("BUILD FAILED: " + $_.Exception.Message) -ForegroundColor Red
    Write-Host "Build tools and downloaded files are kept inside this project folder." -ForegroundColor Yellow
    exit 1
}
