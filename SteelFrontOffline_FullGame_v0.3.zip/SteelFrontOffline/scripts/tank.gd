extends CharacterBody3D

# Decorative, non-functional vehicle model and local driving controller.
# The turret and barrel are static visual details; there is no firing system.
var stats: Dictionary = {}
var is_display: bool = false

func _ready() -> void:
	collision_layer = 2
	collision_mask = 3
	_build_collision()
	_build_model()

func _build_collision() -> void:
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(3.0, 1.40, 5.0)
	collision.shape = shape
	collision.position = Vector3(0.0, 0.72, 0.0)
	add_child(collision)

func _build_model() -> void:
	var body_color: Color = stats.get("color", Color(0.31, 0.37, 0.29))
	var dark_color: Color = body_color.darkened(0.30)
	var light_color: Color = body_color.lightened(0.12)
	var steel_color: Color = Color(0.075, 0.09, 0.095)
	var shape_type: String = str(stats.get("shape", "mbt"))
	var is_light: bool = shape_type == "light"
	var hull_length: float = 4.5 if not is_light else 4.0
	var hull_width: float = 2.75 if not is_light else 2.55
	var hull_height: float = 0.92 if not is_light else 0.78

	# Main hull with sloped front, upper deck and side skirts.
	_make_box(self, Vector3(hull_width, hull_height, hull_length), Vector3(0.0, 0.70, 0.0), body_color, "Hull")
	_make_box(self, Vector3(hull_width * 0.94, 0.20, hull_length * 0.68), Vector3(0.0, 1.18, 0.16), light_color, "UpperDeck")
	var glacis := _make_box(self, Vector3(hull_width * 0.93, 0.38, 1.0), Vector3(0.0, 0.94, -1.78), body_color.lightened(0.04), "FrontGlacis")
	glacis.rotation.x = deg_to_rad(-16.0)
	for side in [-1.0, 1.0]:
		_make_box(self, Vector3(0.34, 0.52, hull_length * 0.92), Vector3(side * 1.43, 0.38, 0.02), dark_color, "TrackAssembly")
		_make_box(self, Vector3(0.18, 0.35, hull_length * 0.72), Vector3(side * 1.53, 0.92, 0.03), body_color.darkened(0.12), "SideSkirt")
		for wheel_index in range(7):
			var wheel_z: float = -1.72 + float(wheel_index) * 0.57
			_make_wheel(side, wheel_z, steel_color, dark_color)
		for tooth_index in range(12):
			var tooth_z: float = -2.05 + float(tooth_index) * 0.37
			_make_box(self, Vector3(0.43, 0.075, 0.12), Vector3(side * 1.45, 0.40, tooth_z), steel_color, "TrackTread")

	# Turret and decorative static barrel assembly. No firing or weapon controls.
	var turret_radius: float = 1.18 if not is_light else 0.94
	_make_cylinder(self, turret_radius, turret_radius, 0.30, Vector3(0.0, 1.30, 0.05), body_color.darkened(0.08), "TurretRing")
	_make_box(self, Vector3(1.95 if not is_light else 1.62, 0.78, 1.88 if not is_light else 1.55), Vector3(0.0, 1.66, -0.12), light_color.darkened(0.04), "Turret")
	_make_box(self, Vector3(1.76, 0.28, 0.62), Vector3(0.0, 1.99, -0.12), body_color, "TurretRoof")
	var barrel_length: float = 3.8 if not is_light else 2.8
	var barrel := _make_cylinder(self, 0.115, 0.095, barrel_length, Vector3(0.0, 1.72, -2.70), steel_color, "StaticBarrel")
	barrel.rotation.x = -PI / 2.0
	var barrel_band := _make_cylinder(self, 0.15, 0.15, 0.22, Vector3(0.0, 1.72, -1.62), dark_color, "BarrelBand")
	barrel_band.rotation.x = -PI / 2.0

	# Hatches, optics, modular armor blocks and front lights.
	for hatch_x in [-0.52, 0.52]:
		_make_cylinder(self, 0.25, 0.25, 0.10, Vector3(hatch_x, 2.18, 0.38), dark_color, "Hatch")
		_make_box(self, Vector3(0.13, 0.12, 0.42), Vector3(hatch_x, 2.29, 0.38), steel_color, "HatchHandle")
	for side in [-1.0, 1.0]:
		for module_index in range(3):
			var module_z: float = -0.68 + float(module_index) * 0.66
			_make_box(self, Vector3(0.24, 0.42, 0.48), Vector3(side * 1.08, 1.66, module_z), body_color.darkened(0.16), "TurretModule")
		_make_box(self, Vector3(0.16, 0.30, 0.52), Vector3(side * 1.44, 1.28, 0.05), dark_color, "SideArmor")
		_make_cylinder(self, 0.09, 0.09, 0.12, Vector3(side * 0.98, 2.20, 0.70), steel_color, "Optic")
	for headlight_x in [-0.92, 0.92]:
		var headlight := _make_box(self, Vector3(0.28, 0.19, 0.12), Vector3(headlight_x, 0.83, -2.23), Color(0.72, 0.75, 0.67), "Headlight")
		var headlight_material: StandardMaterial3D = headlight.material_override as StandardMaterial3D
		headlight_material.emission_enabled = true
		headlight_material.emission = Color(0.25, 0.27, 0.20)
		_make_box(self, Vector3(0.38, 0.12, 0.14), Vector3(headlight_x, 0.64, -2.22), steel_color, "LightGuard")
	_make_box(self, Vector3(0.9, 0.14, 0.35), Vector3(0.0, 1.18, 2.18), dark_color, "RearDeck")
	_make_box(self, Vector3(0.40, 0.22, 0.55), Vector3(-0.82, 1.22, 1.78), dark_color, "Exhaust")
	_make_box(self, Vector3(0.40, 0.22, 0.55), Vector3(0.82, 1.22, 1.78), dark_color, "Exhaust")
	_make_box(self, Vector3(0.16, 0.12, 0.32), Vector3(0.0, 2.36, 0.15), steel_color, "Sensor")

func _make_wheel(side: float, wheel_z: float, steel_color: Color, wheel_color: Color) -> void:
	var wheel := MeshInstance3D.new()
	var wheel_mesh := CylinderMesh.new()
	wheel_mesh.top_radius = 0.34
	wheel_mesh.bottom_radius = 0.34
	wheel_mesh.height = 0.22
	wheel.mesh = wheel_mesh
	wheel.rotation.z = PI / 2.0
	wheel.position = Vector3(side * 1.47, 0.36, wheel_z)
	wheel.material_override = _material(wheel_color)
	add_child(wheel)
	var hub := MeshInstance3D.new()
	var hub_mesh := CylinderMesh.new()
	hub_mesh.top_radius = 0.13
	hub_mesh.bottom_radius = 0.13
	hub_mesh.height = 0.245
	hub.mesh = hub_mesh
	hub.rotation.z = PI / 2.0
	hub.position = Vector3(side * 1.49, 0.36, wheel_z)
	hub.material_override = _material(steel_color.lightened(0.20))
	add_child(hub)

func _physics_process(delta: float) -> void:
	if is_display:
		return
	var throttle: float = 0.0
	var steering: float = 0.0
	if Input.is_key_pressed(KEY_W):
		throttle += 1.0
	if Input.is_key_pressed(KEY_S):
		throttle -= 1.0
	if Input.is_key_pressed(KEY_D):
		steering += 1.0
	if Input.is_key_pressed(KEY_A):
		steering -= 1.0
	var turn_rate: float = float(stats.get("turn", 1.25))
	var drive_speed: float = float(stats.get("speed", 8.0)) * 0.16
	var speed_factor: float = maxf(0.42, absf(throttle))
	rotate_y(steering * turn_rate * speed_factor * delta)
	var desired_velocity: Vector3 = -global_transform.basis.z * throttle * drive_speed
	velocity.x = move_toward(velocity.x, desired_velocity.x, 18.0 * delta)
	velocity.z = move_toward(velocity.z, desired_velocity.z, 18.0 * delta)
	if not is_on_floor():
		velocity.y -= 22.0 * delta
	else:
		velocity.y = 0.0
	move_and_slide()

func _make_box(parent: Node3D, dimensions: Vector3, at: Vector3, color: Color, node_name: String) -> MeshInstance3D:
	var mesh_instance := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = dimensions
	mesh_instance.mesh = box
	mesh_instance.position = at
	mesh_instance.name = node_name
	mesh_instance.material_override = _material(color)
	parent.add_child(mesh_instance)
	return mesh_instance

func _make_cylinder(parent: Node3D, top_radius: float, bottom_radius: float, height: float, at: Vector3, color: Color, node_name: String) -> MeshInstance3D:
	var mesh_instance := MeshInstance3D.new()
	var cylinder := CylinderMesh.new()
	cylinder.top_radius = top_radius
	cylinder.bottom_radius = bottom_radius
	cylinder.height = height
	mesh_instance.mesh = cylinder
	mesh_instance.position = at
	mesh_instance.name = node_name
	mesh_instance.material_override = _material(color)
	parent.add_child(mesh_instance)
	return mesh_instance

func _material(color: Color) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = 0.34
	material.roughness = 0.67
	return material
