extends Node3D

const VehicleScript = preload("res://scripts/tank.gd")

# The vehicle names identify selectable vehicles; all performance values below
# are in-game balance values, not real-world specifications.
const NATIONS := [
	{"id": "ru", "tag": "RU", "name": "РОССИЯ", "subtitle": "СУХОПУТНЫЕ ВОЙСКА", "accent": Color(0.78, 0.25, 0.20)},
	{"id": "cn", "tag": "CN", "name": "КИТАЙ", "subtitle": "НАРОДНО-ОСВОБОДИТЕЛЬНАЯ АРМИЯ", "accent": Color(0.82, 0.24, 0.17)},
	{"id": "us", "tag": "US", "name": "США", "subtitle": "UNITED STATES ARMY", "accent": Color(0.28, 0.48, 0.73)},
	{"id": "eu", "tag": "NATO", "name": "НАТО / ЕС", "subtitle": "ЕВРОПЕЙСКАЯ КОАЛИЦИЯ", "accent": Color(0.36, 0.54, 0.78)},
	{"id": "fr", "tag": "FR", "name": "ФРАНЦИЯ", "subtitle": "ARMÉE DE TERRE", "accent": Color(0.35, 0.49, 0.78)},
	{"id": "se", "tag": "SE", "name": "ШВЕЦИЯ", "subtitle": "SVENSKA ARMÉN", "accent": Color(0.82, 0.67, 0.24)}
]

const VEHICLES := [
	{"id":"t72b3", "nation":"ru", "name":"Т-72Б3", "class":"ОСНОВНОЙ ТАНК", "role":"Универсальная машина", "speed":68, "mobility":72, "stability":78, "color":Color(0.34,0.39,0.27), "shape":"mbt"},
	{"id":"t80bvm", "nation":"ru", "name":"Т-80БВМ", "class":"ОСНОВНОЙ ТАНК", "role":"Высокая динамика", "speed":82, "mobility":86, "stability":70, "color":Color(0.29,0.36,0.27), "shape":"mbt"},
	{"id":"t90m", "nation":"ru", "name":"Т-90М", "class":"ОСНОВНОЙ ТАНК", "role":"Сбалансированная машина", "speed":74, "mobility":76, "stability":84, "color":Color(0.37,0.39,0.28), "shape":"mbt"},
	{"id":"ztz96b", "nation":"cn", "name":"ZTZ96B", "class":"ОСНОВНОЙ ТАНК", "role":"Манёвренная платформа", "speed":76, "mobility":80, "stability":73, "color":Color(0.46,0.43,0.29), "shape":"mbt"},
	{"id":"ztz99a", "nation":"cn", "name":"ZTZ99A", "class":"ОСНОВНОЙ ТАНК", "role":"Тяжёлая платформа", "speed":73, "mobility":74, "stability":86, "color":Color(0.40,0.43,0.31), "shape":"mbt"},
	{"id":"vt4", "nation":"cn", "name":"VT-4", "class":"ОСНОВНОЙ ТАНК", "role":"Экспортная конфигурация", "speed":78, "mobility":78, "stability":76, "color":Color(0.48,0.45,0.32), "shape":"mbt"},
	{"id":"m1a1", "nation":"us", "name":"M1A1 ABRAMS", "class":"ОСНОВНОЙ ТАНК", "role":"Тяжёлая универсальная машина", "speed":70, "mobility":72, "stability":88, "color":Color(0.42,0.43,0.34), "shape":"western"},
	{"id":"m1a2sep", "nation":"us", "name":"M1A2 SEP", "class":"ОСНОВНОЙ ТАНК", "role":"Современная конфигурация", "speed":72, "mobility":74, "stability":90, "color":Color(0.45,0.46,0.35), "shape":"western"},
	{"id":"m10", "nation":"us", "name":"M10 BOOKER", "class":"БОЕВАЯ МАШИНА", "role":"Более лёгкая платформа", "speed":80, "mobility":84, "stability":69, "color":Color(0.37,0.42,0.34), "shape":"light"},
	{"id":"leo2a7", "nation":"eu", "name":"LEOPARD 2A7", "class":"ОСНОВНОЙ ТАНК", "role":"Европейская платформа", "speed":72, "mobility":76, "stability":88, "color":Color(0.44,0.45,0.34), "shape":"western"},
	{"id":"challenger2", "nation":"eu", "name":"CHALLENGER 2", "class":"ОСНОВНОЙ ТАНК", "role":"Тяжёлая конфигурация", "speed":64, "mobility":68, "stability":94, "color":Color(0.40,0.44,0.34), "shape":"western"},
	{"id":"ariete", "nation":"eu", "name":"ARIETE", "class":"ОСНОВНОЙ ТАНК", "role":"Сбалансированная платформа", "speed":70, "mobility":74, "stability":79, "color":Color(0.43,0.43,0.32), "shape":"western"},
	{"id":"leclerc", "nation":"fr", "name":"LECLERC S2", "class":"ОСНОВНОЙ ТАНК", "role":"Высокая подвижность", "speed":82, "mobility":88, "stability":78, "color":Color(0.40,0.44,0.34), "shape":"western"},
	{"id":"leclercxlr", "nation":"fr", "name":"LECLERC XLR", "class":"ОСНОВНОЙ ТАНК", "role":"Модернизированная машина", "speed":80, "mobility":84, "stability":82, "color":Color(0.42,0.45,0.35), "shape":"western"},
	{"id":"amx40", "nation":"fr", "name":"AMX-40", "class":"ОСНОВНОЙ ТАНК", "role":"Лёгкая конфигурация", "speed":84, "mobility":86, "stability":72, "color":Color(0.43,0.46,0.35), "shape":"light"},
	{"id":"strv122", "nation":"se", "name":"STRV 122", "class":"ОСНОВНОЙ ТАНК", "role":"Тяжёлая защита в игровом балансе", "speed":68, "mobility":70, "stability":94, "color":Color(0.45,0.47,0.34), "shape":"western"},
	{"id":"strv121", "nation":"se", "name":"STRV 121", "class":"ОСНОВНОЙ ТАНК", "role":"Универсальная платформа", "speed":70, "mobility":72, "stability":88, "color":Color(0.42,0.46,0.34), "shape":"western"},
	{"id":"cv90120", "nation":"se", "name":"CV 90120", "class":"ЛЁГКАЯ МАШИНА", "role":"Быстрая разведывательная платформа", "speed":88, "mobility":92, "stability":66, "color":Color(0.43,0.48,0.37), "shape":"light"}
]

var selected_nation: String = "ru"
var selected_vehicle: String = "t90m"
var game_state: String = "hangar"
var world_root: Node3D
var camera: Camera3D
var ui_layer: CanvasLayer
var ui_root: Control
var player: CharacterBody3D
var route_points: Array[Vector3] = []
var checkpoint_index: int = 0
var trial_elapsed: float = 0.0
var checkpoint_label: Label
var time_label: Label
var best_times: Dictionary = {}
var last_mode: String = "trial"
var paused_from_state: String = "trial"
var camera_distance: float = 14.0
var camera_yaw: float = 0.0

func _ready() -> void:
	print("[SteelFront] FULL GAME 0.3 / hangar, free drive, time trial, records")
	_load_records()
	_build_scene_shell()
	_build_environment()
	_build_hangar_world()
	_show_hangar_ui()

func _process(delta: float) -> void:
	if (game_state == "trial" or game_state == "free") and is_instance_valid(player):
		trial_elapsed += delta
		var behind: Vector3 = player.global_transform.basis.z.rotated(Vector3.UP, camera_yaw) * camera_distance
		var desired_camera: Vector3 = player.global_position + behind + Vector3(0.0, 7.0, 0.0)
		camera.global_position = camera.global_position.lerp(desired_camera, minf(1.0, delta * 5.0))
		camera.look_at(player.global_position + Vector3(0.0, 1.3, 0.0), Vector3.UP)
		if time_label != null:
			if game_state == "trial":
				time_label.text = "ВРЕМЯ  %s" % _format_time(trial_elapsed)
			else:
				var speed_kmh: int = int(Vector2(player.velocity.x, player.velocity.z).length() * 3.6)
				time_label.text = "СКОРОСТЬ  %03d КМ/Ч" % speed_kmh
		if game_state == "trial" and checkpoint_index < route_points.size():
			var distance: float = player.global_position.distance_to(route_points[checkpoint_index])
			if distance < 4.6:
				checkpoint_index += 1
				if checkpoint_index >= route_points.size():
					_show_result_ui()
					return
			if checkpoint_label != null:
				checkpoint_label.text = "КОНТРОЛЬНАЯ ТОЧКА  %d / %d    •    %.0f м" % [mini(checkpoint_index + 1, route_points.size()), route_points.size(), distance]

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_ESCAPE:
			if game_state == "trial" or game_state == "free":
				_pause_game()
			elif game_state == "paused":
				_resume_game()
		elif event.keycode == KEY_R and (game_state == "trial" or game_state == "free"):
			_restart_current_mode()
	elif event is InputEventMouseButton and event.pressed and (game_state == "trial" or game_state == "free"):
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			camera_distance = maxf(8.0, camera_distance - 1.2)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			camera_distance = minf(25.0, camera_distance + 1.2)
	elif event is InputEventMouseMotion and (game_state == "trial" or game_state == "free"):
		if Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
			camera_yaw = wrapf(camera_yaw - event.relative.x * 0.006, -PI, PI)

func _build_scene_shell() -> void:
	world_root = Node3D.new()
	world_root.name = "World"
	add_child(world_root)
	camera = Camera3D.new()
	camera.name = "MainCamera"
	camera.fov = 48.0
	add_child(camera)
	ui_layer = CanvasLayer.new()
	ui_layer.layer = 5
	add_child(ui_layer)
	ui_root = Control.new()
	ui_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_layer.add_child(ui_root)

func _build_environment() -> void:
	var world_environment := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_material := ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color(0.035, 0.055, 0.085)
	sky_material.sky_horizon_color = Color(0.20, 0.25, 0.29)
	sky_material.ground_bottom_color = Color(0.035, 0.045, 0.05)
	sky_material.ground_horizon_color = Color(0.15, 0.18, 0.19)
	sky.sky_material = sky_material
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.57, 0.62, 0.66)
	environment.ambient_light_energy = 0.72
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	world_environment.environment = environment
	add_child(world_environment)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48.0, -30.0, 0.0)
	sun.light_energy = 1.05
	sun.shadow_enabled = true
	add_child(sun)

func _clear_world() -> void:
	player = null
	for child in world_root.get_children():
		world_root.remove_child(child)
		child.queue_free()

func _clear_ui() -> void:
	for child in ui_root.get_children():
		ui_root.remove_child(child)
		child.queue_free()
	checkpoint_label = null
	time_label = null

func _build_hangar_world() -> void:
	_clear_world()
	game_state = "hangar"
	_add_floor(100.0, Color(0.105, 0.12, 0.13))

	# Industrial hangar shell, roof trusses and service structures.
	_add_visual_box(Vector3(68.0, 17.0, 1.0), Vector3(0.0, 8.0, -25.0), Color(0.105, 0.13, 0.15))
	_add_visual_box(Vector3(1.0, 15.0, 52.0), Vector3(-32.0, 7.0, -1.0), Color(0.075, 0.095, 0.11))
	_add_visual_box(Vector3(1.0, 15.0, 52.0), Vector3(32.0, 7.0, -1.0), Color(0.075, 0.095, 0.11))
	_add_visual_box(Vector3(68.0, 0.7, 52.0), Vector3(0.0, 15.7, -1.0), Color(0.055, 0.07, 0.08))
	for x_pos in [-29.0, -18.0, 18.0, 29.0]:
		for z_pos in [-20.0, -4.0, 12.0]:
			_add_visual_box(Vector3(0.85, 14.0, 0.85), Vector3(x_pos, 7.0, z_pos), Color(0.18, 0.21, 0.22))
			_add_visual_box(Vector3(1.15, 0.22, 1.15), Vector3(x_pos, 13.9, z_pos), Color(0.42, 0.34, 0.22))
	for z_pos in [-21.0, -14.0, -7.0, 0.0, 7.0, 14.0]:
		_add_visual_box(Vector3(64.0, 0.32, 0.55), Vector3(0.0, 14.8, z_pos), Color(0.17, 0.20, 0.21))
		_add_visual_box(Vector3(0.28, 0.22, 48.0), Vector3(0.0, 14.45, z_pos), Color(0.20, 0.23, 0.23))
		_add_visual_box(Vector3(12.0, 0.10, 0.55), Vector3(0.0, 14.42, z_pos + 0.8), Color(0.75, 0.60, 0.35))

	# Large sliding door and segmented industrial wall panels.
	_add_visual_box(Vector3(34.0, 11.5, 0.45), Vector3(0.0, 6.1, -24.35), Color(0.045, 0.065, 0.075))
	for panel_index in range(17):
		var panel_x: float = -16.0 + float(panel_index) * 2.0
		_add_visual_box(Vector3(0.08, 10.8, 0.12), Vector3(panel_x, 6.1, -24.08), Color(0.19, 0.22, 0.22))
	for x_pos in [-16.5, 16.5]:
		_add_visual_box(Vector3(0.32, 12.0, 0.5), Vector3(x_pos, 6.2, -23.75), Color(0.63, 0.40, 0.16))

	# Floor service lanes and a low vehicle display turntable.
	for x_pos in [-17.5, 17.5]:
		_add_visual_box(Vector3(0.14, 0.025, 48.0), Vector3(x_pos, 0.015, -1.0), Color(0.82, 0.55, 0.18))
	for z_pos in [-16.0, 16.0]:
		_add_visual_box(Vector3(35.0, 0.025, 0.14), Vector3(0.0, 0.018, z_pos), Color(0.76, 0.53, 0.20))
	var platform := MeshInstance3D.new()
	var platform_mesh := CylinderMesh.new()
	platform_mesh.top_radius = 5.5
	platform_mesh.bottom_radius = 5.5
	platform_mesh.height = 0.22
	platform.mesh = platform_mesh
	platform.position = Vector3(0.0, 0.11, 0.0)
	platform.material_override = _make_material(Color(0.15, 0.18, 0.19), 0.48)
	world_root.add_child(platform)
	for angle_index in range(24):
		var angle: float = TAU * float(angle_index) / 24.0
		var stripe := MeshInstance3D.new()
		var stripe_mesh := BoxMesh.new()
		stripe_mesh.size = Vector3(0.30, 0.025, 0.85)
		stripe.mesh = stripe_mesh
		stripe.position = Vector3(cos(angle) * 5.18, 0.235, sin(angle) * 5.18)
		stripe.rotation.y = -angle
		stripe.material_override = _make_material(Color(0.73, 0.49, 0.18), 0.25)
		world_root.add_child(stripe)

	# Maintenance props, safety rails, lamps and warning signs.
	for side in [-1.0, 1.0]:
		for index in range(3):
			var crate_pos := Vector3(side * 24.0, 1.1, -10.0 + float(index) * 7.0)
			_add_visual_box(Vector3(3.5, 2.2, 3.0), crate_pos, Color(0.16, 0.19, 0.18))
			_add_visual_box(Vector3(3.65, 0.12, 0.12), crate_pos + Vector3(0.0, 0.0, 1.56), Color(0.48, 0.37, 0.21))
		_add_visual_box(Vector3(5.8, 0.5, 0.6), Vector3(side * 21.0, 1.6, 18.0), Color(0.75, 0.42, 0.13))
	for light_pos in [Vector3(-14.0, 12.0, -3.0), Vector3(0.0, 12.0, -3.0), Vector3(14.0, 12.0, -3.0), Vector3(-14.0, 12.0, 12.0), Vector3(14.0, 12.0, 12.0)]:
		var lamp := OmniLight3D.new()
		lamp.position = light_pos
		lamp.light_color = Color(0.82, 0.88, 0.92)
		lamp.light_energy = 1.15
		lamp.omni_range = 20.0
		lamp.shadow_enabled = false
		world_root.add_child(lamp)
		_add_visual_box(Vector3(3.2, 0.12, 0.42), light_pos + Vector3(0.0, 0.1, 0.0), Color(0.80, 0.82, 0.76))
	var red_light := OmniLight3D.new()
	red_light.position = Vector3(0.0, 8.0, -22.6)
	red_light.light_color = Color(0.72, 0.15, 0.10)
	red_light.light_energy = 1.1
	red_light.omni_range = 16.0
	world_root.add_child(red_light)

	# Main selected vehicle and two background display vehicles.
	var selected: Dictionary = _get_vehicle(selected_vehicle)
	_add_showcase_vehicle(selected, Vector3(0.0, 0.20, 0.0), 1.0, deg_to_rad(-28.0))
	var secondary_a: Dictionary = _get_vehicle("m1a2sep")
	var secondary_b: Dictionary = _get_vehicle("leo2a7")
	_add_showcase_vehicle(secondary_a, Vector3(-13.5, 0.0, -8.8), 0.72, deg_to_rad(20.0))
	_add_showcase_vehicle(secondary_b, Vector3(14.5, 0.0, -9.6), 0.70, deg_to_rad(-8.0))

	camera.make_current()
	camera.global_position = Vector3(8.8, 6.0, 12.5)
	camera.look_at(Vector3(0.0, 1.25, -1.2), Vector3.UP)

func _add_showcase_vehicle(data: Dictionary, at: Vector3, model_scale: float, yaw: float) -> void:
	if data.is_empty():
		return
	var showcase = VehicleScript.new()
	showcase.stats = data
	showcase.is_display = true
	world_root.add_child(showcase)
	showcase.position = at
	showcase.scale = Vector3.ONE * model_scale
	showcase.rotation.y = yaw

func _add_floor(extent: float, color: Color) -> void:
	var floor_body := StaticBody3D.new()
	floor_body.name = "Ground"
	floor_body.collision_layer = 1
	floor_body.collision_mask = 0
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(extent, 0.6, extent)
	collision.shape = shape
	collision.position.y = -0.3
	floor_body.add_child(collision)
	var visual := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(extent, 0.6, extent)
	visual.mesh = box
	visual.position.y = -0.3
	visual.material_override = _make_material(color, 0.18)
	floor_body.add_child(visual)
	world_root.add_child(floor_body)

func _add_visual_box(dimensions: Vector3, at: Vector3, color: Color) -> void:
	var mesh_instance := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = dimensions
	mesh_instance.mesh = box
	mesh_instance.position = at
	mesh_instance.material_override = _make_material(color, 0.28)
	world_root.add_child(mesh_instance)

func _add_obstacle(dimensions: Vector3, at: Vector3, color: Color) -> void:
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	body.position = at
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = dimensions
	collision.shape = shape
	body.add_child(collision)
	var visual := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = dimensions
	visual.mesh = box
	visual.material_override = _make_material(color, 0.18)
	body.add_child(visual)
	world_root.add_child(body)

func _add_checkpoint_gate(at: Vector3, checkpoint_number: int) -> void:
	var gate_material := _make_material(Color(0.16, 0.80, 0.66), 0.18)
	gate_material.emission_enabled = true
	gate_material.emission = Color(0.06, 0.48, 0.35)
	gate_material.emission_energy_multiplier = 1.1
	for side in [-1.0, 1.0]:
		_add_world_box(Vector3(0.25, 3.6, 0.25), at + Vector3(side * 2.2, 1.8, 0.0), gate_material)
	_add_world_box(Vector3(4.7, 0.25, 0.25), at + Vector3(0.0, 3.6, 0.0), gate_material)

func _add_world_box(dimensions: Vector3, at: Vector3, material: StandardMaterial3D) -> void:
	var mesh_instance := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = dimensions
	mesh_instance.mesh = box
	mesh_instance.position = at
	mesh_instance.material_override = material
	world_root.add_child(mesh_instance)

func _make_material(color: Color, metallic: float = 0.2) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = metallic
	material.roughness = 0.72
	return material

func _show_hangar_ui() -> void:
	_clear_ui()
	var shade := ColorRect.new()
	shade.color = Color(0.006, 0.012, 0.018, 0.18)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.add_child(shade)

	var header := _make_panel(Vector2(0.0, 0.0), Vector2(1280.0, 88.0), Color(0.018, 0.028, 0.038, 0.96), false)
	ui_root.add_child(header)
	var header_content := Control.new()
	header_content.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	header.add_child(header_content)
	var logo := _make_label("STEEL FRONT", 27, Color(0.88, 0.90, 0.88))
	logo.position = Vector2(23.0, 10.0)
	logo.size = Vector2(250.0, 36.0)
	header_content.add_child(logo)
	var logo_sub := _make_label("OFFLINE   /   VEHICLE SIMULATOR", 10, Color(0.74, 0.40, 0.25))
	logo_sub.position = Vector2(25.0, 46.0)
	logo_sub.size = Vector2(250.0, 22.0)
	header_content.add_child(logo_sub)
	var nation_x: float = 288.0
	for nation_variant in NATIONS:
		var nation: Dictionary = nation_variant
		var nation_button := _make_nation_button(nation)
		nation_button.position = Vector2(nation_x, 14.0)
		nation_button.size = Vector2(154.0, 58.0)
		header_content.add_child(nation_button)
		nation_x += 158.0

	# Vehicle roster panel on the left.
	var left_panel := _make_panel(Vector2(22.0, 108.0), Vector2(310.0, 476.0), Color(0.018, 0.029, 0.038, 0.91))
	var left_layout := VBoxContainer.new()
	left_layout.add_theme_constant_override("separation", 8)
	left_panel.add_child(left_layout)
	left_layout.add_child(_make_label("ПАРК ТЕХНИКИ", 19, Color(0.91, 0.92, 0.89)))
	var nation_data: Dictionary = _get_nation(selected_nation)
	left_layout.add_child(_make_label(str(nation_data.get("subtitle", "")), 9, Color(0.74, 0.43, 0.28)))
	var roster: Array[Dictionary] = _vehicles_for_nation(selected_nation)
	for vehicle_data in roster:
		var chosen: bool = str(vehicle_data["id"]) == selected_vehicle
		var marker: String = "  ◆  " if chosen else "  ▸  "
		var vehicle_text: String = marker + str(vehicle_data["name"]) + "\n       " + str(vehicle_data["class"])
		var vehicle_button := _make_button(vehicle_text, _select_vehicle.bind(str(vehicle_data["id"])), 76.0, chosen)
		vehicle_button.add_theme_font_size_override("font_size", 13)
		left_layout.add_child(vehicle_button)
	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	left_layout.add_child(spacer)
	left_layout.add_child(_make_label("ДОСТУПНО  18 / 18     •     ВСЁ ОТКРЫТО", 10, Color(0.55, 0.73, 0.68)))

	# Vehicle profile panel on the right.
	var right_panel := _make_panel(Vector2(950.0, 108.0), Vector2(308.0, 476.0), Color(0.018, 0.029, 0.038, 0.91))
	var right_layout := VBoxContainer.new()
	right_layout.add_theme_constant_override("separation", 9)
	right_panel.add_child(right_layout)
	var vehicle: Dictionary = _get_vehicle(selected_vehicle)
	right_layout.add_child(_make_label("КАРТОЧКА МАШИНЫ", 18, Color(0.91, 0.92, 0.89)))
	right_layout.add_child(_make_label(str(vehicle.get("name", "")), 25, Color(0.88, 0.58, 0.30)))
	right_layout.add_child(_make_label(str(vehicle.get("class", "")), 10, Color(0.70, 0.77, 0.76)))
	var role_label := _make_label(str(vehicle.get("role", "")), 12, Color(0.74, 0.79, 0.77))
	role_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	role_label.custom_minimum_size = Vector2(0.0, 40.0)
	right_layout.add_child(role_label)
	right_layout.add_child(HSeparator.new())
	right_layout.add_child(_make_stat_bar("СКОРОСТЬ", float(vehicle.get("speed", 50))))
	right_layout.add_child(_make_stat_bar("МАНЁВРЕННОСТЬ", float(vehicle.get("mobility", 50))))
	right_layout.add_child(_make_stat_bar("УСТОЙЧИВОСТЬ", float(vehicle.get("stability", 50))))	
	var stat_note := _make_label("Показатели условные и относятся к игровому балансу.", 9, Color(0.49, 0.59, 0.59))
	stat_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	right_layout.add_child(stat_note)
	var best_value: float = float(best_times.get(selected_vehicle, 0.0))
	var best_text: String = "ЛУЧШЕЕ ВРЕМЯ: %s" % _format_time(best_value) if best_value > 0.0 else "ЛУЧШЕЕ ВРЕМЯ: НЕТ"
	right_layout.add_child(_make_label(best_text, 10, Color(0.74, 0.78, 0.70)))
	var right_spacer := Control.new()
	right_spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right_layout.add_child(right_spacer)
	right_layout.add_child(_make_label("ЛОКАЛЬНЫЙ РЕЖИМ  •  БЕЗ ИНТЕРНЕТА", 9, Color(0.60, 0.72, 0.69)))

	# Bottom control strip and prominent practice button.
	var controls_panel := _make_panel(Vector2(22.0, 598.0), Vector2(690.0, 98.0), Color(0.018, 0.029, 0.038, 0.91))
	var controls_layout := VBoxContainer.new()
	controls_layout.add_theme_constant_override("separation", 6)
	controls_panel.add_child(controls_layout)
	controls_layout.add_child(_make_label("АНГАР   /   УПРАВЛЕНИЕ", 12, Color(0.88, 0.90, 0.87)))
	controls_layout.add_child(_make_label("W / S — движение     A / D — поворот     ESC — вернуться в ангар", 11, Color(0.64, 0.72, 0.70)))
	var play_panel := _make_panel(Vector2(850.0, 574.0), Vector2(408.0, 124.0), Color(0.018, 0.029, 0.038, 0.94))
	var play_layout := VBoxContainer.new()
	play_layout.add_theme_constant_override("separation", 4)
	play_panel.add_child(play_layout)
	play_layout.add_child(_make_button("ЗАЕЗД НА ВРЕМЯ  〉", _start_trial, 39.0, true))
	play_layout.add_child(_make_button("СВОБОДНАЯ ТРЕНИРОВКА", _start_free_drive, 39.0, false))
	var offline_label := _make_label("ЛОКАЛЬНАЯ ИГРА   •   БЕЗ СЕТЕВЫХ СЕРВЕРОВ", 9, Color(0.62, 0.73, 0.70))
	offline_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	play_layout.add_child(offline_label)

func _show_trial_ui() -> void:
	_clear_ui()
	var is_free_drive: bool = game_state == "free"
	var status_panel := _make_panel(Vector2(22.0, 20.0), Vector2(420.0, 142.0), Color(0.018, 0.029, 0.038, 0.90))
	var status_layout := VBoxContainer.new()
	status_layout.add_theme_constant_override("separation", 8)
	status_panel.add_child(status_layout)
	var status_title := "СВОБОДНАЯ ТРЕНИРОВКА" if is_free_drive else "ИСПЫТАТЕЛЬНЫЙ ПОЛИГОН"
	status_layout.add_child(_make_label(status_title, 15, Color(0.86, 0.89, 0.86)))
	time_label = _make_label("СКОРОСТЬ  000 КМ/Ч" if is_free_drive else "ВРЕМЯ  00:00.0", 23, Color(0.91, 0.59, 0.31))
	status_layout.add_child(time_label)
	if is_free_drive:
		checkpoint_label = _make_label("СВОБОДНЫЙ ЗАЕЗД  •  МАРШРУТ НЕ ОГРАНИЧЕН", 11, Color(0.72, 0.79, 0.77))
	else:
		checkpoint_label = _make_label("КОНТРОЛЬНАЯ ТОЧКА  1 / %d" % route_points.size(), 12, Color(0.72, 0.79, 0.77))
	status_layout.add_child(checkpoint_label)
	var pause_button := _make_button("ПАУЗА  [ESC]", _pause_game, 44.0, false)
	pause_button.position = Vector2(1042.0, 22.0)
	pause_button.size = Vector2(216.0, 50.0)
	ui_root.add_child(pause_button)
	var controls_panel := _make_panel(Vector2(22.0, 604.0), Vector2(600.0, 92.0), Color(0.018, 0.029, 0.038, 0.88))
	var controls_text := "W / S — движение     A / D — поворот\nПравая кнопка мыши — обзор • Колесо — приближение • R — перезапуск • ESC — пауза"
	var controls := _make_label(controls_text, 11, Color(0.75, 0.81, 0.78))
	controls.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	controls_panel.add_child(controls)

func _show_result_ui() -> void:
	game_state = "result"
	if is_instance_valid(player):
		player.set_physics_process(false)
	var is_new_record: bool = _store_best_time(selected_vehicle, trial_elapsed)
	var overlay := ColorRect.new()
	overlay.color = Color(0.006, 0.010, 0.014, 0.76)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.add_child(overlay)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(460.0, 300.0)
	panel.add_theme_stylebox_override("panel", _panel_style(Color(0.028, 0.043, 0.052, 0.98)))
	center.add_child(panel)
	var layout := VBoxContainer.new()
	layout.add_theme_constant_override("separation", 12)
	panel.add_child(layout)
	var heading := _make_label("МАРШРУТ ПРОЙДЕН", 25, Color(0.91, 0.92, 0.87))
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	layout.add_child(heading)
	var detail := _make_label("Время прохождения: " + _format_time(trial_elapsed), 14, Color(0.72, 0.79, 0.75))
	detail.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	layout.add_child(detail)
	var record_caption: String
	if is_new_record:
		record_caption = "НОВЫЙ ЛИЧНЫЙ РЕКОРД!"
	else:
		record_caption = "ЛУЧШЕЕ ВРЕМЯ: %s" % _format_time(float(best_times.get(selected_vehicle, trial_elapsed)))
	var record_label := _make_label(record_caption, 12, Color(0.84, 0.63, 0.34))
	record_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	layout.add_child(record_label)
	layout.add_child(_make_button("ПОВТОРИТЬ ЗАЕЗД", _restart_current_mode, 44.0, false))
	layout.add_child(_make_button("ВЕРНУТЬСЯ В АНГАР", _return_to_hangar, 44.0, true))

func _pause_game() -> void:
	if game_state != "trial" and game_state != "free":
		return
	paused_from_state = game_state
	game_state = "paused"
	if is_instance_valid(player):
		player.set_physics_process(false)
	_show_pause_ui()

func _resume_game() -> void:
	if game_state != "paused":
		return
	game_state = paused_from_state
	if is_instance_valid(player):
		player.set_physics_process(true)
	_show_trial_ui()

func _show_pause_ui() -> void:
	_clear_ui()
	var overlay := ColorRect.new()
	overlay.color = Color(0.006, 0.010, 0.014, 0.78)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.add_child(overlay)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(400.0, 250.0)
	panel.add_theme_stylebox_override("panel", _panel_style(Color(0.028, 0.043, 0.052, 0.98)))
	center.add_child(panel)
	var layout := VBoxContainer.new()
	layout.add_theme_constant_override("separation", 12)
	panel.add_child(layout)
	var heading := _make_label("ПАУЗА", 25, Color(0.91, 0.92, 0.87))
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	layout.add_child(heading)
	layout.add_child(_make_button("ПРОДОЛЖИТЬ", _resume_game, 44.0, true))
	layout.add_child(_make_button("НАЧАТЬ ЗАНОВО", _restart_current_mode, 44.0, false))
	layout.add_child(_make_button("В АНГАР", _return_to_hangar, 44.0, false))

func _restart_current_mode() -> void:
	if last_mode == "free":
		_start_free_drive()
	else:
		_start_trial()

func _load_records() -> void:
	var config := ConfigFile.new()
	var err: Error = config.load("user://steel_front_records.cfg")
	if err == OK:
		var saved: Variant = config.get_value("records", "best_times", {})
		if saved is Dictionary:
			best_times = saved

func _store_best_time(vehicle_id: String, seconds: float) -> bool:
	var current_best: float = float(best_times.get(vehicle_id, 0.0))
	if current_best > 0.0 and current_best <= seconds:
		return false
	best_times[vehicle_id] = seconds
	var config := ConfigFile.new()
	config.set_value("records", "best_times", best_times)
	var err: Error = config.save("user://steel_front_records.cfg")
	if err != OK:
		push_warning("Не удалось сохранить личный рекорд: %s" % error_string(err))
	return true

func _make_panel(at: Vector2, dimensions: Vector2, color: Color, add_to_ui: bool = true) -> PanelContainer:
	var panel := PanelContainer.new()
	panel.position = at
	panel.size = dimensions
	panel.custom_minimum_size = dimensions
	panel.add_theme_stylebox_override("panel", _panel_style(color))
	if add_to_ui:
		ui_root.add_child(panel)
	return panel

func _panel_style(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = Color(0.25, 0.31, 0.33, 0.92)
	style.set_border_width_all(1)
	style.set_corner_radius_all(3)
	style.content_margin_left = 15.0
	style.content_margin_right = 15.0
	style.content_margin_top = 12.0
	style.content_margin_bottom = 12.0
	return style

func _make_label(caption: String, font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = caption
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	return label

func _make_button(caption: String, callback: Callable, height: float, highlighted: bool) -> Button:
	var button := Button.new()
	button.text = caption
	button.custom_minimum_size = Vector2(0.0, height)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.focus_mode = Control.FOCUS_NONE
	button.add_theme_font_size_override("font_size", 13)
	button.add_theme_color_override("font_color", Color(0.88, 0.90, 0.88))
	button.add_theme_color_override("font_hover_color", Color(1.0, 1.0, 1.0))
	button.add_theme_stylebox_override("normal", _button_style(Color(0.075, 0.105, 0.12) if not highlighted else Color(0.34, 0.095, 0.065)))
	button.add_theme_stylebox_override("hover", _button_style(Color(0.13, 0.17, 0.18) if not highlighted else Color(0.52, 0.14, 0.085)))
	button.add_theme_stylebox_override("pressed", _button_style(Color(0.055, 0.075, 0.08)))
	button.pressed.connect(callback)
	return button

func _make_nation_button(nation: Dictionary) -> Button:
	var nation_id: String = str(nation["id"])
	var selected: bool = nation_id == selected_nation
	var button := Button.new()
	button.text = str(nation["tag"]) + "\n" + str(nation["name"])
	button.focus_mode = Control.FOCUS_NONE
	button.add_theme_font_size_override("font_size", 11)
	button.add_theme_color_override("font_color", Color(0.94, 0.94, 0.90))
	button.add_theme_color_override("font_hover_color", Color(1.0, 1.0, 1.0))
	var accent: Color = nation["accent"]
	button.add_theme_stylebox_override("normal", _button_style(Color(accent.r * 0.26, accent.g * 0.26, accent.b * 0.26, 0.92) if selected else Color(0.055, 0.075, 0.085, 0.95)))
	button.add_theme_stylebox_override("hover", _button_style(Color(accent.r * 0.42, accent.g * 0.42, accent.b * 0.42, 0.98)))
	button.add_theme_stylebox_override("pressed", _button_style(Color(0.08, 0.10, 0.11)))
	button.pressed.connect(_select_nation.bind(nation_id))
	return button

func _button_style(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = Color(0.40, 0.43, 0.42, 0.82)
	style.set_border_width_all(1)
	style.set_corner_radius_all(3)
	style.content_margin_left = 10.0
	style.content_margin_right = 10.0
	return style

func _make_stat_bar(caption: String, stat_value: float) -> Control:
	var holder := VBoxContainer.new()
	holder.add_theme_constant_override("separation", 3)
	var row := HBoxContainer.new()
	var title := _make_label(caption, 10, Color(0.73, 0.79, 0.76))
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(title)
	var value_label := _make_label("%d" % int(stat_value), 10, Color(0.88, 0.62, 0.36))
	row.add_child(value_label)
	holder.add_child(row)
	var bar := ProgressBar.new()
	bar.min_value = 0.0
	bar.max_value = 100.0
	bar.value = clampf(stat_value, 0.0, 100.0)
	bar.show_percentage = false
	bar.custom_minimum_size = Vector2(0.0, 9.0)
	holder.add_child(bar)
	return holder

func _select_nation(nation_id: String) -> void:
	if _get_nation(nation_id).is_empty():
		return
	selected_nation = nation_id
	var available: Array[Dictionary] = _vehicles_for_nation(selected_nation)
	if available.size() > 0:
		selected_vehicle = str(available[0]["id"])
	_build_hangar_world()
	_show_hangar_ui()

func _select_vehicle(vehicle_id: String) -> void:
	var data: Dictionary = _get_vehicle(vehicle_id)
	if data.is_empty():
		return
	selected_vehicle = vehicle_id
	_build_hangar_world()
	_show_hangar_ui()

func _get_nation(nation_id: String) -> Dictionary:
	for nation_variant in NATIONS:
		var nation: Dictionary = nation_variant
		if str(nation["id"]) == nation_id:
			return nation
	return {}

func _get_vehicle(vehicle_id: String) -> Dictionary:
	for vehicle_variant in VEHICLES:
		var vehicle: Dictionary = vehicle_variant
		if str(vehicle["id"]) == vehicle_id:
			return vehicle
	return {}

func _vehicles_for_nation(nation_id: String) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for vehicle_variant in VEHICLES:
		var vehicle: Dictionary = vehicle_variant
		if str(vehicle["nation"]) == nation_id:
			result.append(vehicle)
	return result

func _start_trial() -> void:
	last_mode = "trial"
	camera_distance = 14.0
	camera_yaw = 0.0
	_clear_world()
	game_state = "trial"
	trial_elapsed = 0.0
	checkpoint_index = 0
	route_points = [
		Vector3(0.0, 0.0, -16.0),
		Vector3(18.0, 0.0, -19.0),
		Vector3(25.0, 0.0, 3.0),
		Vector3(13.0, 0.0, 22.0),
		Vector3(-15.0, 0.0, 19.0),
		Vector3(-24.0, 0.0, -4.0)
	]
	_add_floor(110.0, Color(0.16, 0.17, 0.16))
	_add_obstacle(Vector3(108.0, 0.5, 0.8), Vector3(0.0, 0.25, -52.0), Color(0.11, 0.14, 0.15))
	_add_obstacle(Vector3(108.0, 0.5, 0.8), Vector3(0.0, 0.25, 52.0), Color(0.11, 0.14, 0.15))
	for x_pos in [-48.0, 48.0]:
		_add_obstacle(Vector3(0.8, 0.5, 104.0), Vector3(x_pos, 0.25, 0.0), Color(0.11, 0.14, 0.15))
	for lane in [-12.0, 12.0]:
		_add_visual_box(Vector3(0.18, 0.025, 92.0), Vector3(lane, 0.015, 0.0), Color(0.76, 0.58, 0.24))
	_add_obstacle(Vector3(7.0, 2.2, 2.0), Vector3(-8.0, 1.1, 2.0), Color(0.28, 0.29, 0.27))
	_add_obstacle(Vector3(2.0, 2.0, 7.0), Vector3(7.0, 1.0, -5.0), Color(0.31, 0.29, 0.25))
	_add_obstacle(Vector3(5.0, 1.5, 2.0), Vector3(16.0, 0.75, 8.0), Color(0.25, 0.29, 0.27))
	_add_obstacle(Vector3(3.0, 2.5, 3.0), Vector3(-19.0, 1.25, -12.0), Color(0.27, 0.28, 0.27))
	_add_obstacle(Vector3(6.0, 1.3, 2.0), Vector3(0.0, 0.65, -24.0), Color(0.29, 0.30, 0.28))
	_add_obstacle(Vector3(2.0, 1.8, 6.0), Vector3(-24.0, 0.9, 12.0), Color(0.27, 0.28, 0.27))
	for index in range(route_points.size()):
		_add_checkpoint_gate(route_points[index], index + 1)
	player = _spawn_vehicle(selected_vehicle, Vector3(0.0, 0.0, 17.0))
	camera.make_current()
	camera.global_position = Vector3(0.0, 8.0, 29.0)
	camera.look_at(player.global_position + Vector3(0.0, 1.0, 0.0), Vector3.UP)
	_show_trial_ui()

func _start_free_drive() -> void:
	_start_trial()
	last_mode = "free"
	game_state = "free"
	route_points.clear()
	checkpoint_index = 0
	_show_trial_ui()

func _spawn_vehicle(vehicle_id: String, at: Vector3) -> CharacterBody3D:
	var vehicle = VehicleScript.new()
	vehicle.stats = _get_vehicle(vehicle_id)
	vehicle.is_display = false
	world_root.add_child(vehicle)
	vehicle.global_position = at
	return vehicle

func _return_to_hangar() -> void:
	route_points.clear()
	_build_hangar_world()
	_show_hangar_ui()

func _format_time(seconds: float) -> String:
	var minutes: int = int(seconds / 60.0)
	var remaining: float = fmod(seconds, 60.0)
	return "%02d:%04.1f" % [minutes, remaining]
