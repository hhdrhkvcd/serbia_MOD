STEEL FRONT OFFLINE — DIAGNOSTICS

The game uses Godot 4.3 with the Compatibility renderer. The build script
checks project import and GDScript parsing before exporting the Windows EXE.
It does not run the 3D scene in Dummy Renderer headless mode; the final EXE
runs with the normal desktop renderer.

If the game window is blank:
1. Close the game.
2. Run RUN_DIAGNOSTICS.bat.
3. It starts the game with verbose logging and writes startup_log.txt.
4. Keep the log and share its contents when asking for help.

This is an original offline vehicle-driving prototype. It does not connect
to War Thunder or Dagor Editor.
